/**
  * Merwyn B. Celmar, ITCC A
  * October 5, 2020
  */
  
import javax.swing.JFrame;
import javax.swing.JButton;

Class JFrame{
	public static void main(String[] args){
	
	buttons b = new buttons;
	
}
}